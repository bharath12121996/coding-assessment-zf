﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CodingAssessment.Domain
{
    public static class Constants   
    {
        public const string FromEmailAddress = "your-email@gmail.com";
        public const string FromEmailName = "From Name";
        public const string ToEmailAddress = "recipient@example.com";
        public const string ToEmailName = "Receipient Name";
        public const string FromEmailPassword = "Letter";
        public const string Subject = "Subject of the Email";
    }
}
